===============================================================================
     �uThe Installation Procedure of the USB Driver to Windows 7 host PC�v
===============================================================================

  This document is the USB driver installation manual for connecting
  Windows7 host PC with the FLASH Programmer for Toshiba TX and TXZ MCU.
  Please be sure to read this document before you install the USB driver.


===============================================================================

 [Contents]
  -----------------------------------------------------------------------------
  1. USB driver files

  2. The installation procedure of the USB driver

  3. The uninstallation procedure of the USB driver

  4. The uninstallation procedure of the old USB driver

  -----------------------------------------------------------------------------

1. USB driver files
  -----------------------------------------------------------------------------
   The following files are stored in this USB driver package 
  "Drivers-Win7-TxCmWinUsb".

    Drivers-Win7-TxCmWinUsb
    ��
    ������TxCmWinUSB-Readme.txt
    ��
    ������x64(Driver folder for Windows7 64Bit)
    ��      ������TxCmWinUsbDrv.cat
    ��      ������TxCmWinUsbDrv.inf
    ��      ������WdfCoInstaller01011.dll
    ��      ������winusbcoinstaller2.dll
    ��
    ������x86(Driver folder for Windows7 32Bit)
            ������TxCmWinUsbDrv.cat
            ������TxCmWinUsbDrv.inf
            ������WdfCoInstaller01011.dll
            ������winusbcoinstaller2.dll

  -----------------------------------------------------------------------------

2. The installation procedure of the USB driver

  The installation procedure of the driver is described.

  Please uninstall the old USB driver.
  Next, please install the this USB driver.
    �u4.The uninstallation procedure of the old USB driver�v

  ---------------------------------------------------------------------------
   (1)First connect the target system to host PC with a USB cable.
      When it is connected with host PC for the first time, the message
      of "Device driver software was not successfully installed" is displayed.
   (2)Then, Start the Device Manager by choosing [Control Panel]-[Device Manager].
   (3)Right-click on the system of use in the "Other Devices" list and choose
      "Update Driver Software" in the pop-up menu.
   (4)Click "Browse my computer for driver software."
   (5)      Push the [Browse] button of [Search for driver software in this location],
      and choose the USB driver folder.
        x64(Driver folder for Windows7 64Bit)
        x86(Driver folder for Windows7 32Bit)
   (6)Click the [Next] button.
   (7)Since the message of "Windows has successfully updated your driver
      software" is displayed, click the "Close" button.

  This will end the Installation of the USB driver.
  ---------------------------------------------------------------------------

3.The uninstallation procedure of the USB driver

  The uninstallation procedure of the driver is described.

  ---------------------------------------------------------------------------
   (1)Connect the target system of use to host PC with a USB cable.
      It is unnecessary when the system has already been connected to the PC.
   (2)Start the Device Manager by choosing [Control Panel]-[Device Manager].
      It is unnecessary when the Device Manager has already started.
   (3)Double-click the [Universal Serial Bus Controllers] and it develops.
   (4)Right-click The system of use and choose "Properties" in the pop-up menu.
        [TOSHIBA TXCM WinUSB Driver 64]  (for Windows7 64Bit)
        [TOSHIBA TXCM WinUSB Driver 32]  (for Windows7 32Bit)
   (5)In a Properties dialog, choose a [Driver Tab] and click [Uninstall]
      button.
   (6)Check the check box of [Delete the driver software for this device], when
      the check box is dislayed in the [Confirm Device Uninstall] dialog.
   (7)Click the "OK" button.

    Uninstallation of the USB driver is finished.

    Please remove the target system of use from host PC.

  ---------------------------------------------------------------------------

4.The uninstallation procedure of the old USB driver

  The uninstallation procedure of the old driver is described.

  ---------------------------------------------------------------------------
   (1)Connect the target system of use to host PC with a USB cable.
      It is unnecessary when the system has already been connected to the PC.
   (2)Start the Device Manager by choosing [Control Panel]-[Device Manager].
      It is unnecessary when the Device Manager has already started.
   (3)Double-click the [Universal Serial Bus Controllers] and it develops.
   (4)Right-click The system of use and choose "Properties" in the pop-up menu.
        [TXCMUSBDRV.SYS TOSHIBA USB Driver]
        [TX03USBDRV.Sys TOSHIBA USB Driver]
   (5)In a Properties dialog, choose a [Driver Tab] and click [Uninstall]
      button.
   (6)Check the check box of [Delete the driver software for this device], when
      the check box is dislayed in the [Confirm Device Uninstall] dialog.
   (7)Click the "OK" button.

    Uninstallation of the old USB driver is finished.

    Please remove the target system of use from host PC.
  ---------------------------------------------------------------------------

=== END ===
