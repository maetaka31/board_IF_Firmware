Copyright(C) 2018 Toshiba Electronic Devices & Storage Corporation, All rights reserved.

=========================================
�uRelease notes�v
    FLASH Programmer for Toshiba TX and TXZ MCU

Date: 2017-10-10
---------------------------------------------------------------------
Please refer to the following location for the technical information of Flash Programmer:

  (1)SOFTWARE LICENSE AGREEMENT------------ ..\agreement_e.txt
  (2)Release notes(This sentence)---------- ..\readme\readme_e.txt
  (3)Supplement of the setup--------------- ..\readme_setup_e.txt

--------------------------------------------------------------------
The system and product names included in this document are generally
registered trademarks or trademarks of their respective owners.

Copyright(C) 2018 Toshiba Electronic Devices & Storage Corporation, All rights reserved.

