(C)Copyright TOSHIBA MICROELECTRONICS CORPORATION 2017 All rights reserved
===================================================================
"Notes on FLASH Programmer"
-------------------------------------------------------------------


[Notes]
When FlashProgCM.exe does not start.
(When the setup dialog box is not displayed)
Please install either of the followings in accordance 
with OS (x86 or x64) of PC.

  x86:32bit
  x64:64bit

Microsoft Visual C++ 2005 SP1 Redistributable Package (x86)
  Microsoft Visual C++ 2005 Service Pack 1 Redistributable
  Package MFC Security Update
  <http://www.microsoft.com/en-US/download/details.aspx?id=26347>



Please download the following, although two or more programs
are downloadable. 
  [vcredist_x86.exe]
Since application software is 32 bits, PC should use the above also
in the 64-bit environment.

