===============================================================================
The Installation Procedure of the USB(VCP) Driver to Windows 10 host PC
===============================================================================

To the Toshiba Emulation System Users.

  This document is the USB driver installation manual for connecting
  Windows10 host PC with the Toshiba emulation system or FLASH Writer.
  Please be sure to read this document before you install the USB driver.

    The target systems are the following products. 
    BMP89A400010A-G : RTE870/C1 On-Chip Debug Emulation System
    BMP89A300010A-G : RTE870/C1 In-Circuit Emulation System
    HW86EG000AG     : RTE870/C In-Circuit Emulation System
    BM1401W0A-G     : FLASH Writer

===============================================================================

 [Contents]
  -----------------------------------------------------------------------------
  1. USB driver files

  2. The installation procedure of the USB(VCP) driver
    2.1.Installation of the USB driver
    2.2.Installation of the VCP driver

  3. The uninstallation procedure of the USB(VCP) driver
    3.1.Uninstallation of the VCP driver
    3.2.Uninstallation of the USB driver

  4. Connection with Integrated Development Environment (IDE)

  -----------------------------------------------------------------------------

1. USB driver files
  -----------------------------------------------------------------------------
   The following 13 files are stored in this USB driver package "Driver-FFp".

      TSBBM.inf
      TSBFVCP.Inf
      TSBBM.sys
      TSBBM_x64.sys
      TSBBM.dll
      TSBBM_x64.dll
      tsbbm.cat
      tsbfvcp.cat
      TSBFVCP.sys
      TSBFVCP_x64.sys
      TSBBMUN.EXE
      TSBBMUN.INI
      readme.txt
  -----------------------------------------------------------------------------

2. The installation procedure of the USB(VCP) driver

  The installation procedure of the driver is described.
  The drivers to be installed are different according to the system.

  - In case of the emulation system
    Installation of the USB driver is needed.
    Please install the USB driver according to the procedure in the section 2.1.

  - In case of the FLASH Writer
    Installation of the USB driver and the VCP driver is needed. 
    Please install the USB driver according to the procedure in the section  2.1.
    Next, please install the VCP driver according to the procedure in the section 2.2.


  2.1.Installation of the USB driver
  ---------------------------------------------------------------------------
   (1)First connect the system to host PC with a USB cable.
      When it is connected with host PC for the first time, the message
      of "Device driver software was not successfully installed" is displayed.
   (2)Then, Start the Device Manager by choosing [Control Panel]-[Device Manager].
   (3)Right-click on the system of use in the "Other Devices" list and choose
      "Update Driver Software" in the pop-up menu.
      The contents of a display of "Other Devices" are the following.
        TOSHIBA RTE870/C       : BMP86A300010A
        TOSHIBA RTE870/C1 OCDE : BMP89A400010A-G
        TOSHIBA RTE870/C1 ICE  : BMP89A300010A-G
        TOSHIBA RTE870/C ICE   : HW86EG000AG
        TOSHIBA FLASH Writer   : BM1401W0A-G
   (4)Click "Browse my computer for driver software."
   (5)Push the [Browse] button of [Search for driver software in this location],
      and choose the USB driver folder, "Driver-FFp".
   (6)Click the [Next] button.
   (7)Since the message of "Windows has successfully updated your driver
      software" is displayed, click the "Close" button.

   This will end the Installation of the USB driver.

  In case of the FLASH writer, please perform the procedure in "2.2. installation 
  of the VCP driver" continuously.

  ---------------------------------------------------------------------------
  2.2.Installation of the VCP driver
  ---------------------------------------------------------------------------
   (1)If the USB driver is not installed, then install the USB driver first.
      Refer to "2.1.Installation of the USB driver".
   (2)Start the Device Manager by choosing [Control Panel]-[Device Manager].
      It is unnecessary when the Device Manager has already started.
   (3)Right-click the system of use in the list under "USB Serial Port", and
      choose "Update Driver Software" in the pop-up menu.
   (4)Click "Browse my computer for driver software."
   (5)Push the [Browse] button of [Search for driver software in this location],
      and choose the USB driver folder, "Driver-FFp".
   (6)Click the [Next] button.
   (7)Since the message of "Windows has successfully updated your driver
      software" is displayed, click "Close" button.

  This will end the Installation of the VCP driver.

  ---------------------------------------------------------------------------

3.The uninstallation procedure of the USB(VCP) driver

  The uninstallation procedure of the driver is described.
  The drivers to be uninstalled are different according to the system.

  - In case of the emulation system,
    uninstallation of the USB driver is needed.
    Please uninstall the USB driver according to the procedure in the section 3.2.

  - In case of use of the FLASH Writer
    Uninstallation of the USB driver and the VCP driver is needed.
    Please uninstall the VCP driver according to the section 3.1.
    Next, please uninstall the USB driver according to the procedure in the 
    section 3.2.


  3.1.Uninstallation of the VCP driver
  ---------------------------------------------------------------------------
   (1)Connect The FLASH writer to host PC with a USB cable.
   (2)Start the Device Manager by choosing [Control Panel]-[Device Manager].
   (3)Double-click [Ports (COM & LPT)] and it develops.
   (4)Right-click [TOSHIBA VCP (COM*)] and choose "Properties" in the pop-up menu.
      Port number "*" of COM is different according to the PC environment.
   (5)In a Properties dialog, choose a [Driver Tab] and click [Uninstall] button.
   (6)Check the check box of [Delete the driver software for this device], when
      the check box is dislayed in the [Confirm Device Uninstall] dialog.
   (7)Click the "OK" button.

  Uninstallation of the VCP driver is finished.
  Next, please uninstall the USB driver by the procudure in the section 3.2.

  Please keep the FLASH writer connected to host PC by the USB cable. 
  ---------------------------------------------------------------------------

  3.2.Uninstallation of the USB driver
  ---------------------------------------------------------------------------
   (1)Connect the system of use to host PC with a USB cable.
      It is unnecessary when the system has already been connected to the PC.
   (2)Start the Device Manager by choosing [Control Panel]-[Device Manager].
      It is unnecessary when the Device Manager has already started.
   (3)Double-click the [Universal Serial Bus Controllers] and it develops.
   (4)Right-click The system of use and choose "Properties" in the pop-up menu.

      TYPE of each system displayed by the Device Manager is the following.

        [TOSHIBA RTE SYSTEM TYPE](Emulation System)
          TYPE1 : BMP86A300010A
          TYPE2 : BMP89A400010A-G
          TYPE3 : BMP89A300010A-G
          TYPE7 : HW86EG000AG
        [TOSHIBA SEI SYSTEM TYPE](FLASH Writer)
          TYPE2 : BM1401W0A-G
   (5)In a Properties dialog, choose a [Driver Tab] and click [Uninstall]
      button.
   (6)Check the check box of [Delete the driver software for this device], when
      the check box is dislayed in the [Confirm Device Uninstall] dialog.
   (7)Click the "OK" button.

    Uninstallation of the USB driver is finished.

    Please remove the system of use from host PC.
  ---------------------------------------------------------------------------

4.Connection with Integrated Development Environment (IDE)

  When connection with Integrated Development Environment (IDE) goes
  wrong after USB driver installation in the 64-bit environment,
  please set timeout time longer than the default value (20 seconds)
  by "Profile Property"-"Other Connection Settings"-"Connection Time Out".

=== END ===
