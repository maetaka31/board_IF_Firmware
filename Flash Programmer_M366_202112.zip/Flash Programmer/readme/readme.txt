===================================================================
[Release Note]
    Update to FLASH Adapter Control Program "FLASH Programmer"

Date: Oct. 14th, 2020

FLASH Programmer Ver4.21
This version number indicates the revision number of the product 
package (not the revision number of each tool or file contained in 
the product package).
In this update, A new device is added to the supported device list.
===================================================================

Introduction

This document provides the following information on the FLASH
Programmer (updated version). The FLASH Programmer is an application
program to be used on the programming board for Toshiba MCUs with
FLASH memory.

        1. Software License Agreement
        2. Configuration of Extracted Files
        3. Uninstallation
        4. Technical Information
        5. Operation Manual
        6. Supported Devices
        7. Technical Support

[1] Software License Agreement
      When you extract the downloaded file, the license agreement
      for using the updated FLASH Programmer can be found in the
      following location:

      C:\Program Files\Toshiba\Flash Programmer\readme\agreement.txt

[2] Uninstallation
    To uninstall the FLASH Programmer, follow the steps below.
    1. Select [Settings] - [Control Panel] from the Windows [Start]
       menu.
    2. Double-click [Add or Remove Programs]. The Add or Remove
       Programs dialog box opens.
    3. Select [Change or Remove Programs].
    4. Select "FLASH Programmer" on the list  and then click the
       [Remove] button.
    5. When the uninstaller starts up, follow the instructions on
       the screen.
    6. If a folder contains files/folders other than those originally
       installed or files/folders installed for update, the uninstaller
       will not delete those files/folders. For this reason, the
       following folder may remain. In this case, delete the unwanted
       folders and files manually.

         C:\Program Files\Toshiba\Flash Programmer


[3] Technical Information
     This section provides technical information for using this
     product.
     1. Wiring Table
        The wiring table for wiring the FLASH Adapter is provided for
        each supported device in a folder having the name of each
        device.
        For example, if you are using the TMP86FM26, the wiring table
        for this device can be found in the following location:

        C:\Program Files\Toshiba\Flash Programmer\TMP86FM26
          \Wiring_86FM26.pdf

        Use this PDF file for wiring the FLASH Adapter. Adobe Reader
        is required to open this file.

        The FLASH Adapter must be wired as specified in the provided
        wiring table. After wiring, make sure to check that all
        connections are made correctly. Otherwise, the device may be
        damaged. After wiring, each
        user should assume responsibility for performing operation
        verifications.

      2. Operation Manual
         The operation manual of the FLASH Programmer can be opened by
         the following methods.
         * Select [Program] - [TOSHIBA Flash Programmer] - [FLASH
           Programmer operation manual] from the Windows [Start] menu.
         * After starting the FLASH Programmer, select [Help] -
           [FLASH Programmer Help F1] on the menu bar.
         * Double-click C:\Program Files\Toshiba\Flash Programmer
           \help.pdf.

           Adobe Reader is required to view this operation manual.

      3. Supplementary Documentation
         Supplementary documentation is available for providing
         technical information unique to each device. When using the
         FLASH Programmer, refer both the operation manual and
         supplementary documentation.
         Supplementary documentation is stored in a folder named
         each device�fs part number of the installation folder.

         Example: When the device is the TMP86FM26

         C:\Program Files\Toshiba\FLASH Programmer\TMP86FM26
           \readme86FM26.txt

[4] Supported Devices
     For the part number of each product and how to configure the 
     development system for your target device, please use the search 
     system of this website.
     By searching for your target device, you can view the detailed 
     information on your target device together with a list of the 
     development system products to be used.

       Web site: https://toshiba.semicon-storage.com/ap-en/product/microcomputer.html


[5] Technical Support
     If you need any further information on this product, please
     contact your local Toshiba office.
     If you encounter any phenomenon that seems faulty while using
     this product, please let us know. We will investigate the matter
     and get back to you. To request this service, you will be
     required to provide us with necessary data (operation procedure,
     etc.) for reproducing the phenomenon. Please note that we may
     not be able to provide technical support for unreproducible
     phenomena.

-------------------------------------------------------------------
The system and product names included in this document are generally
registered trademarks or trademarks of their respective owners.
(C)2020 TOSHIBA ELECTRONIC DEVICES & STORAGE CORPORATION, All Rights Reserved.
